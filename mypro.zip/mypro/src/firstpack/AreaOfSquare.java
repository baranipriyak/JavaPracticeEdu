package firstpack;

public class AreaOfSquare {

	public static void main(String[] args) {
		int len=40;
		int area = len*len;
		System.out.println("Area of Square :"+area);

	}

}
