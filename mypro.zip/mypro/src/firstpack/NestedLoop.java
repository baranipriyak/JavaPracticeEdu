package firstpack;

public class NestedLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=4;i++){ //i=1, i=2
			   for(int j=1;j<=i;j++){ //j will execute 1 to 3
			       // System.out.println("i="+i+ " and j="+j);
				  // System.out.print(i+" ");
				   System.out.print(i+" ");
			   }
			   System.out.println();


			}

	}

}
