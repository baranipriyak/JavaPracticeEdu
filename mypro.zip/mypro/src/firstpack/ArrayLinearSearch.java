package firstpack;

import java.util.Scanner;

public class ArrayLinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = new int[5];
		
	    Scanner scanner = new Scanner(System.in);
        System.out.println("Enter array elements");
        
        for(int i=0;i<a.length;i++) {
            a[i]=scanner.nextInt();
        }
        
        //display
        for(int i=-0;i<a.length;i++) {
        	System.out.println(a[i]);
        }
        
        System.out.println("Enter search element :");
        int key = scanner.nextInt();
        int pos =0;
        
        for(int i=0;i<a.length;i++) {
        	if(key==a[i]) {
        		pos+=1;
        		break;
        	}
        }
        if(pos>0) {
        	System.out.println("Successfull search");
        	System.out.println("The element position is :"+pos);
        }
        else {
        	System.out.println("Unsuccessfull search");
        }
        
        //how many time 
        System.out.println("Enter the element");
        int element = scanner.nextInt();
        int accurence = 0;
        for (int i=0;i<a.length;i++) {
        	if(a[i]==element) {
        		accurence+=1;
        	}
        }
        
	}

}
