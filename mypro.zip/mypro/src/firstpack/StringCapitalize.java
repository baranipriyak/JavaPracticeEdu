//Write a java program to capitalize each word in string 
package firstpack;

public class StringCapitalize {

	public static void main(String[] args) {
		String str1 = "hi how are you";
		System.out.print(str1.charAt(0));
		for(int i=1;i<str1.length();i++) {
			if((str1.charAt(i))==' ') {
				
			}
			
			
		}

	}

}
