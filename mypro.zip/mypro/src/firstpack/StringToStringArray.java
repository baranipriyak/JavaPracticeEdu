//Java Program to convert String to StringArray
package firstpack;

public class StringToStringArray {

	public static void main(String[] args) {
		String str = "Hi How are you?";
		String strArray[] = str.split(" ");
		
		System.out.println("String :"+str);
		System.out.print("After converting String Array : [ ");
		
		for(int i=0;i<strArray.length;i++) {
			System.out.print(strArray[i]+",");
		}
		System.out.println(" ]");

	}

}
