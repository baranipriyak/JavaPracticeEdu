package firstpack;

import java.util.Scanner;

public class IfElseDemo {
	
	int no , no1 , no2 , no3 ;
	Scanner sc = new Scanner(System.in);
	
	void posNeg() {
		System.out.println("Enter the number :");
		no = sc.nextInt();
		if (no>0) {
			System.out.println(no +" is a positive number.");
		}
		else {
			System.out.println(no +" is a negative number.");
		}
	}
	
	void evenOdd(){
		
		
		if (no%2 == 0) {
			System.out.println(no +" is an even number");
		}
		else {
			System.out.println(no+ " is an odd number ");
		}
		
	}
	
	void max() {
		System.out.println("Enter the number1 :");
		no1 = sc.nextInt();
		System.out.println("Enter the number2 :");
		no2 = sc.nextInt();
		System.out.println("Enter the number3 :");
		no3 = sc.nextInt();
		
		if (no1>no2 && no1>no3) {
			System.out.println(no1 +" is greater");
		}
		else if (no2>no1 && no2>no3) {
			System.out.println(no2 +" is greater");
		}
		else {
			System.out.println(no3+" is greater");
		}
	}
	
	void swap() {
		System.out.println("Enter the number 1 :");
		no1 = sc.nextInt();
		System.out.println("Enter the number 2 :");
		no2 = sc.nextInt();
		int temp = no1;
		no1 = no2;
		no2 = temp;
		System.out.println("no1 :"+no1);
		System.out.println("no2 :"+no2);
	}
	
	void swapTwo() {
		System.out.println("Enter the number 1:");
		no1 = sc.nextInt();
		System.out.println("Enter the number 2:");
		no2 = sc.nextInt();
		no1 = no1+no2;
		no2 = no1-no2;
		no1 = no1-no2;
		System.out.println("no1 :"+no1);
		System.out.println("no2 :"+no2);
	}

	public static void main(String[] args) {
		
		IfElseDemo ifd = new IfElseDemo();
		ifd.posNeg();
		ifd.evenOdd();
		ifd.max();
		ifd.swap();
		ifd.swapTwo();
	}

}
