package firstpack;

import java.util.Scanner;

public class StudentRegistration {

	public static void main(String[] args) {
		
		String name;
		int age;
		String standard;
		char gender;
		
		
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Student Registration");
		
		System.out.println("Enter the name :");
		name = sc.nextLine();
		
		System.out.println("Enter the age :");
		age = sc.nextInt();
		
		System.out.println("Enter the standard :");
		sc.nextLine();
		standard = sc.nextLine();
		
		System.out.println("Enter the gender :");
		gender = sc.next().charAt(0);
		
		System.out.println("Name = "+name);
		System.out.println("Age = "+age);
		System.out.println("Standrad = "+standard);
		System.out.println("Gender = "+gender);
		

		
		
		

	}

}
