package firstpack;

public class ArithmeticOperator {
	public static void main(String args[]) {
		int num1=1000;
		int num2=10;
		
		System.out.println("Addition of two numbers:"+(num1+num2));
		System.out.println("Subraction of two numbers: "+(num1-num2));
		System.out.println("Multiplication of two numbers: "+(num1*num2));
		System.out.println("division of two numbers it will give a quentiant : "+(num1/num2));
		System.out.println("Modulo division to give a reminder :"+(num1%num2));
		
	}

}
