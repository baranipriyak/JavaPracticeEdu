package firstpack;

import java.util.Scanner;

public class Eshop {
	
	String item_name ;
	double price;
	double net_amount;
	
	
	void accept() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the item name :");
		item_name = sc.nextLine();
		System.out.println("Enter price :");
		price = sc.nextDouble();		
	}
	void calculate() {
		double discount_amount;
		if (price>=1000 && price<=25000) {
			discount_amount = price*(5.0/100);
			System.out.println(discount_amount);
			net_amount = price-discount_amount;
		}
		else if (price>25000 && price<=57000) {
			discount_amount = price*(7.5/100);
			net_amount = price-discount_amount;
		}
		else if (price>57000 && price<=100000) {
			discount_amount = price*(10.0/100);
			net_amount = price-discount_amount;
		}
		else {
			discount_amount = price*(15.0/100);
			net_amount = price-discount_amount;
		}
	}
	
	void display() {
		System.out.println("Name of the item :"+item_name);
		System.out.println("The net amount is :"+net_amount);
	}

	public static void main(String[] args) {
		
		Eshop eshop = new Eshop();
		
		eshop.accept();
		eshop.calculate();
		eshop.display();

	}

}
