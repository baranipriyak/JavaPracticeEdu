package firstpack;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declare array
		
        //int a[]=new int[5];
        //or
       // int b[];
      //  b=new int[5];
        
        int c[]= {5,3,4,6,8};
                //0 1 2 3 4
        for(int i=0;i<c.length;i++)
        System.out.println("c["+i+"]="+c[i]);

	}

}
