package firstpack;

public class WhileLoopOdd {

	public static void main(String[] args) {
		int i=1,sum=0;
		while (i<=100) {
			sum+=i;
			i=i+2;
		}
		System.out.println("The sum of odd numbers 1 to 100 :"+sum);

	}

}
