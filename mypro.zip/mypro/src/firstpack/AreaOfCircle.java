package firstpack;

public class AreaOfCircle {

	public static void main(String[] args) {
		double radius=3;
		double area = 3.14159*radius*radius;
		System.out.println("Area of Circle :"+area);
		System.out.println(4+5+"hello");

	}

}
