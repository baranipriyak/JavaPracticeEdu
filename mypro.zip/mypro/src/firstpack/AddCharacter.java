//Java program to Add Characters to a String
package firstpack;

public class AddCharacter {

	public static void main(String[] args) {
		
		String str1 = "Baranipriya";
		String str2 = "Hi";
		
		//Add beginning
		
		String add = str2+str1;
		System.out.println(add);
		
		//another way to add using concat
		System.out.println(str2.concat(str1));
		
		//Add to end
		add = str1+str2;
		System.out.println(add);
		
		//another way to add using concat
		System.out.println(str1.concat(str2));
		
		//added the character inbetween
		
		add = str1.substring(0,6)+str2+str1.substring(6);
		System.out.println(add);

	}

}
