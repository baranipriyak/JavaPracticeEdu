package firstpack;

import java.util.Scanner;

public class StudentStream {
	String name;
	int age;
	int marks;
	String stream;
	
	void accept() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name :");
		name = sc.nextLine();
		System.out.println("Enter the age :");
		age = sc.nextInt();
		System.out.println("Enter total marks :");
		marks = sc.nextInt();
	}
	
	void allocation() {
		if (marks>=300) {
			stream = "Science and Computer";
		}
		else if (marks>=200 && marks<300) {
			stream = "Commerce and Computer";
		}
		else if (marks>=75 && marks<200) {
			stream = "Arts and Animation";
		}
		else if (marks<75) {
			stream = "Try Again";
		}
	}
	
	void print() {
		System.out.println("Student name :"+name);
		System.out.println("Student age :"+age);
		System.out.println("Student marks :"+marks);
		System.out.println("Stream allocated is :"+stream);
	}

	public static void main(String[] args) {
		
		StudentStream ss = new StudentStream();
		ss.accept();
		ss.allocation();
		ss.print();

	}

}
