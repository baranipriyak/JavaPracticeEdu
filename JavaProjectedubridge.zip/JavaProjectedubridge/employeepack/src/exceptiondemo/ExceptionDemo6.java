package exceptiondemo;


public class ExceptionDemo6 {


	public static void main(String[] args) {
		int a=10,b=0,c;
		String name=null;
		System.out.println("Before division");
		try {
			System.out.println(name.length());
			if(b==0) {
			    throw new ArithmeticException("Denominator is Zero, cannot divide");
		    }else {
		    	c=a/b;
		    	System.out.println(c);
		    }
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


}
