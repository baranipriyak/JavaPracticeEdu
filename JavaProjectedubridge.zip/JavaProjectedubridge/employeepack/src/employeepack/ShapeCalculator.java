package employeepack;

public class ShapeCalculator {

    // (i) Compute square or cube of an integer based on character argument
    void compute(int num, char operation) {
        if (operation == 's') {
            int square = num * num;
            System.out.println("Square of " + num + " is: " + square);
        } else {
            int cube = num * num * num;
            System.out.println("Cube of " + num + " is: " + cube);
        }
    }

    // (ii) Compute volume or diagonal of a cube based on character argument
    void compute(double side, char operation) {
        if (operation == 'v') {
            double volume = Math.pow(side, 3);
            System.out.println("Volume of cube with side " + side + " is: " + volume);
        } else {
            double diagonal = side * Math.sqrt(3);
            System.out.println("Diagonal of cube with side " + side + " is: " + diagonal);
        }
    }

    // (iii) Compute area or perimeter of a rectangle based on character argument
    void compute(int length, int breadth, char operation) {
        if (operation == 'a') {
            int area = length * breadth;
            System.out.println("Area of rectangle with length " + length + " and breadth " + breadth + " is: " + area);
        } else {
            int perimeter = 2 * (length + breadth);
            System.out.println("Perimeter of rectangle with length " + length + " and breadth " + breadth + " is: " + perimeter);
        }
    }

    public static void main(String[] args) {
        ShapeCalculator calculator = new ShapeCalculator();

        // Test cases
        calculator.compute(4, 's'); // Square of 4
        calculator.compute(3, 'c'); // Cube of 3
        calculator.compute(5.0, 'v'); // Volume of cube with side 5.0
        calculator.compute(6.0, 'd'); // Diagonal of cube with side 6.0
        calculator.compute(7, 4, 'a'); // Area of rectangle 7 x 4
        calculator.compute(7, 4, 'p'); // Perimeter of rectangle 7 x 4
    }
}