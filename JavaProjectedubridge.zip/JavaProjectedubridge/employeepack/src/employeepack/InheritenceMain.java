package employeepack;


import java.util.Scanner;


class Parent{
	final int num =7;
	 int i,j, s;
	 public Parent() {
		 this.i=0;
		 this.j=0;
		 System.out.println("No argument constr");
	 }
	 public Parent(int i, int j) {
		 this.i=i;
		 this.j=j;
		 
	 }
	void inputData() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter two values");
		i = scanner.nextInt();
		j = scanner.nextInt();
	}
	void add() {
		s=i+j;
	}
	//public->protected->default->private
	 void display() {
		System.out.println("The sum of "+i+" and "+j+" is "+s);
	}
	
}


class Child extends Parent{ //Single Inheritence
	int num;
	public Child(int i, int j) {
		//System.out.println("hello");
		super(i, j); //in child constructor super should be first line
		
	}
	void subtract() {
		s=i-j;
	}
	
	 void display() { //overriden method , runtime polymorphisam
		super.display();
		System.out.println("The difference of "+i+" and "+j+" is "+s);
		
	}
}
public class InheritenceMain {


	public static void main(String[] args) {
//		Parent parent = new Parent();
//		parent.inputData();
//		parent.add();
//		parent.display();
		
		Child child = new Child(9,8);//child class constr is called
		//child.inputData();
		child.add();
		child.subtract();
		child.display();


	}


}

