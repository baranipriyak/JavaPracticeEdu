package employeepack;

public class VolumeOfShapes {
	public int cube;
	public double sphere;
	public double cuboid;
		
	void volume (int area) {
		cube = area*area*area;
		System.out.println("Volume of cube is :"+cube);
	}
	void volume(double r) {
		sphere = ((double)(4/3))*3.14*r*r*r;
		System.out.println("Volume of sphere is :"+sphere);
	}
	void volume(double l , double h, double b) {
		cuboid = l*b*h;
		System.out.println("Volume of cuboid is :"+cuboid);
	}

	public static void main(String[] args) {
		VolumeOfShapes volumeOfShapes = new VolumeOfShapes();
		volumeOfShapes.volume(5);
		volumeOfShapes.volume(3.4);
		volumeOfShapes.volume(8, 10, 5);

	}

}
