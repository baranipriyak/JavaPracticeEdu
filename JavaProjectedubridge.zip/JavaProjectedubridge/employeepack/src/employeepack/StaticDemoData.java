package employeepack;

import java.util.Scanner;

public class StaticDemoData {
   static int i; //0
   int j; //0
   
   public StaticDemoData() {
	   i++;
	   j++;
	   
	   System.out.println("static i="+i);
	   System.out.println("Non static j="+j);
   }
	public static void main(String []args) {
		StaticDemoData sdd = new StaticDemoData();
		StaticDemoData sdd1 = new StaticDemoData();
//		Scanner sc = new Scanner(System.in); 
	}

}
