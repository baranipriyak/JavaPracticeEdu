package employeepack;

public class FunctionSeries {
	double result=0.0;
	int product ;
	
	void series(int a,int n) {
		
			for(int i=1;i<=10;i++) {
				product=1;
				for(int j=i;j>=1;j--) {
					product*=j;
				}
				if(i%2==0) {
					result -=(double)a/product;
				}
				else {
					result +=(double)a/product;
				}
				
			}
	
			System.out.println("1/1!+1/2!+1/3!+1/4!+.......+1/10! = "+result);

		}
			
		
	void series(int n) {
		result = 0.0;
		for(int i=1;i<=n;i++) {
			if(i%2 ==0) {
				result -= (double) i/(i+1);
			}
			else {
				result +=(double)i/(i+1);
			}
		}
		System.out.println("1/2 -2/3+3/4-4/5+....... "+result);
	}

	public static void main(String[] args) {
		FunctionSeries functionSeries = new FunctionSeries();
		functionSeries.series(1, 10);
		functionSeries.series(8);

	}

}
