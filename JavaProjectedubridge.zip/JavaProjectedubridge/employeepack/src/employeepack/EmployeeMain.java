package employeepack;

import java.util.Scanner;

class Employee{
	private String e_name;
	private int e_id;
	private int age;
	private float salary;
	
	
	
	public Employee() {
		super();
		e_name = "Barani";
	}

	public Employee(String e_name, int e_id, int age, float salary) {
		super();
		this.e_name = e_name;
		this.e_id = e_id;
		this.age = age;
		this.salary = salary;
	}
	
	public String getE_name() {
		return e_name;
	}
	public void setE_name(String e_name) {
		this.e_name = e_name;
	}
	public int getE_id() {
		return e_id;
	}
	public void setE_id(int e_id) {
		this.e_id = e_id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	void inputEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee name :");
		e_name = sc.nextLine();
		System.out.println("Enter employee id :");
		e_id = sc.nextInt();
		System.out.println("Enter employee age :");
		age = sc.nextInt();
		System.out.println("Enter salary :");
		salary = sc.nextFloat();
	}
	void displayEmployeeData() {
		System.out.println("Employee name :"+e_name);
		System.out.println("Employee Id :"+e_id);
		System.out.println("Employee Age :"+age);
		System.out.println("Employee Salary :"+salary);
	}
	
	
}

public class EmployeeMain {

	public static void main(String[] args) {
		//Employee employee1 = new Employee("Madhuri" , 2 , 23 , 60000);
		Employee employee = new Employee();
		employee.inputEmployee();
		
//		employee1.setE_name("Baranipriya");
//		employee1.setE_id(1);
//		employee1.setAge(24);
//		employee1.setSalary(50000);
//		System.out.println("Employee name :"+employee1.getE_name());
//		System.out.println("Employee Id :"+employee1.getE_id());
//		System.out.println("Employee Age :"+employee1.getAge());
//		System.out.println("Employee salary :"+employee1.getSalary());
		
		employee.displayEmployeeData();

	}

}
