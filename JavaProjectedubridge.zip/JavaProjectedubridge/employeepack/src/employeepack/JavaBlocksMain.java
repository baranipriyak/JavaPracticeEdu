package employeepack;


public class JavaBlocksMain {
  
	static {
		System.out.println("static block1");
	}
	static {
		System.out.println("static block2");
	}
	
	{
	     System.out.println("annonymous block 1");	
	}
	{
	     System.out.println("annonymous block 2");	
	}
	public JavaBlocksMain() {
		super();
		System.out.println("Constructor block");
	}


	public static void main(String[] args) {
		System.out.println("Main method block" );
		JavaBlocksMain javaBlocksMain = new JavaBlocksMain();
	}


}
