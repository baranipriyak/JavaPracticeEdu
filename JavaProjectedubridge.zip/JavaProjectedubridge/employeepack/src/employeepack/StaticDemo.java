package employeepack;


class Employee1{
	int eid;
	String ename;
	static String cname;
	
	public Employee1(int eid, String ename) {
		this.eid = eid;
		this.ename=ename;
	}
	static {
		cname="EduBridgeIndia Pvt.ltd";
	}
	
	void displayData() {
		System.out.println("Id="+eid);
		System.out.println("Name="+ename);
		System.out.println("Cname="+cname);
	}
	
	static void staticMethod() {
		//System.out.println(eid);
		System.out.println(cname);
	}
}


public class StaticDemo {
   static int i;
	public static void main(String[] args) {
		Employee1 employee1 = new Employee1(1111,"Sweta");
		Employee1 employee2 = new Employee1(1112,"Madhuri");
		employee1.displayData();
		employee2.displayData();
        System.out.println(i);
        System.out.println(employee1.cname);




	}


}

