package employeepack;

public class AbstractMain {

	public static void main(String[] args) {
		System.out.println(true && false || true);

	}
}

abstract class Shape{
  abstract public void area();
  public void display(){
  }
}

class Square extends Shape{
   public void area(){
        int l=7;
        int area = l*l;
       
   }
}
