package employeepack;

import java.util.Scanner;

class SecondSmallest{
	public int[] arr = new int[10];
	
	void InputData() {
		for(int i=0;i<10;i++) {
			Scanner sc = new Scanner(System.in);
			arr[i]=sc.nextInt();
		}
	}
	
	int getSecondSmallest(int arr[]) {
		for(int i=0;i<arr.length;i++) {
			for(int j=1;j<=arr.length-1-i;j++) {
				if(arr[j]>arr[j+1]) {
					int temp = arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		return arr[2];
	}
	
}

public class SecondSmallestMain {

	public static void main(String[] args) {
		SecondSmallest ss = new SecondSmallest();
		ss.InputData();
		int secondsmall=ss.getSecondSmallest(ss.arr);
		System.out.println(secondsmall);
		

	}

}
