package PracCollection;

import java.util.ArrayList;

public class MyArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a[]=new int[4];
		
				ArrayList<Integer> alist = new ArrayList<Integer>();
				alist.add(34);
				alist.add(341);
				alist.add(134);
				alist.add(334);
				alist.add(634);
				alist.add(734);
				System.out.println(alist);
				//alist.clear();
				alist.removeFirst();
				alist.removeLast();
				alist.add(2, 100);
				System.out.println(alist);
				
				//Float
				ArrayList<Float> alist1 = new ArrayList<Float>();
				alist1.add(9.0f);
				alist1.add(89.0f);
				alist1.add(898.0f);
				alist1.add(1087.0f);
				alist1.add(8.0f);
				
				System.out.println(alist1);
				
				//String
				ArrayList<String> alist2 = new ArrayList<String>();
				alist2.add("Barani");
				alist2.add("Priya");
				alist2.add("Kalai");
				alist2.add("Madhuri");
				System.out.println(alist2);
				
				//LinkedList
				//Vector

	}

}
