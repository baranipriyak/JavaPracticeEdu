package PracCollection;

public class TestArrayObject {

	public static void main(String[] args) {
		Object obj[] = {101 , "Barani",688.78};
		System.out.println(obj[0]);
		System.out.println(obj[1]);
		System.out.println(obj[2]);

	}

}
