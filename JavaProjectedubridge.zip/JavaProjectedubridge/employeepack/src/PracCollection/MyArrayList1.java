package PracCollection;

import java.util.ArrayList;

public class MyArrayList1 {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();//Stored to hetrogenious values
		//ArrayList<Object> al = new ArrayList<>();
		
		System.out.println(al);
		System.out.println(al.size());
		
		al.add(100);
		al.add(600);
		System.out.println(al);
		System.out.println(al.size());
		
		al.add("Java");
		System.out.println(al);
		System.out.println(al.size());
		
		al.set(1, "C");
		System.out.println(al);
		System.out.println(al.size());
		
		al.add(1,200);
		System.out.println(al);
		System.out.println(al.size());
		
		for(Object al1 :al) {
			System.out.println(al1);
		}
		
		//Generic version of ArrayList 
				ArrayList<String> courses = new ArrayList<String>();
				courses.add("JFS");
				courses.add("PFS");
				courses.add("MEAN");
				courses.add("MERN");
				//courses.add(1001); //CE
				System.out.println(courses);
				System.out.println(courses.get(1));
				
				for(String course :courses) {
					System.out.println(course);
				}
			
		
		/*
		1. ArrayList is growable in nature
		2. Duplicates are allowed
		3. Maintained insertion order
		*/
		
	}

}
