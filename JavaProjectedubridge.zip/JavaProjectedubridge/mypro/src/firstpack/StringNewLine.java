//Java String program to print a new line in string
package firstpack;

public class StringNewLine {

	public static void main(String[] args) {
//		String newline = System.lineSeparator();
//		System.out.println("Barani"+newline+"Priya");
		
		
//		String newline = System.getProperty("line.separator");
//		System.out.println("Barani"+newline+"Priya");
		
//		System.out.printf("Barani%nPriya");
		
//		System.out.println("Barani"+"\n"+"Priya");
		
		System.out.println("Barani");
		System.out.println("Priya");

	}

}
