// Java program to get a specific character
// from a given String at a specific index

package firstpack;

public class GetACharacter {

	public static void main(String[] args) {
		String str = "Baranipriya";
		
		int index = 5;
		System.out.println("Character from " +str+" at index "+index+" is :"+str.charAt(index));
		
		//another way to solve in using toCharArray()
		System.out.println("Character from "+str+" at index "+index+" is :"+str.toCharArray()[index]);
		
		//another way to solve using codePointAt()
		System.out.println("Character from "+str+" at index "+index+" is :"+(char)(str.codePointAt(index)));

	}

}
