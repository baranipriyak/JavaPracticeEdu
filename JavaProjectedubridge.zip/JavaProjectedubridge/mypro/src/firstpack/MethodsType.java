package firstpack;


import java.util.Scanner;


public class MethodsType {
 
	void addition() {  //no return type no argument
		int n1,n2,ans;
		Scanner scanner = new Scanner(System.in);
		   System.out.println("Enter First number");
		   n1=scanner.nextInt();
		   n2=scanner.nextInt();
		  ans = n1+n2;
		  System.out.println("The sum of "+n1+" and "+n2+" is "+ans);
				
	}
	
	void subtraction(int n1,int n2) { //method with argument and no return type
		int res;
		res = n1-n2;
		System.out.println("The differenence of "+n1+" and "+n2+" is "+res);
	}
	
	int multiplication() { //with return type and no argument
		
		int n1,n2,ans;
		Scanner scanner = new Scanner(System.in);
		   System.out.println("Enter First number");
		   n1=scanner.nextInt();
		   n2=scanner.nextInt();
		   ans = n1*n2;
		return ans;  //with return type and no argument
		
		
	}
	
	float division(int i, int j) { //method with argument and with return type
		float res;
		res =(float)i/j;
		return res;
		
	}
	
	public static void main(String[] args) {
		MethodsType methodsType= new MethodsType();
		methodsType.addition();
		int p,q,ans;
		Scanner scanner = new Scanner(System.in);
		   System.out.println("Enter First number");
		   p=scanner.nextInt();
		  q=scanner.nextInt();
		   methodsType.subtraction(p, q); //method with argument
		   
		int result=methodsType.multiplication();
		System.out.println("Product ="+result);
		
		//float r = methodsType.division(p,q);
		System.out.println("Quotient = "+methodsType.division(p,q));
		
		
	}


}
