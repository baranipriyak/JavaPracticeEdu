package firstpack;

import java.util.Scanner;

class Armstrong{//153 1*1*1+5*5*5+3*3*3 = 153 
	// 1 -> 1 
	// 45 -> 4*4+5*5 ->41
	
	
	int num, reminder , num1 , pow=0;
	double arm=0;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number :");
		num = sc.nextInt();
	}
	
	void calculate() {
		num1 = num;
		while (num !=0) {
			num=num/10;
			pow+=1;
		}
		num = num1;
		
		while (num !=0) {
			reminder = num%10;
			arm = arm +Math.pow(reminder, pow);
			num =num/10;
		}
		
	}
	void print() {
		if(arm == num1) {
			System.out.println("It is a Armstrong number");
		}
		else {
			System.out.println("It is not a Armstrong number");
		}
	}
	
}

public class ArmstrongEncapsulation {

	public static void main(String[] args) {
		Armstrong a = new Armstrong();
		a.inputData();
		a.calculate();
		a.print();

	}

}
