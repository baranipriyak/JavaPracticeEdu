package firstpack;

import java.util.Scanner;

public class InputArrayElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a[]=new int[5];
				int []a=new int[5];
				int sum=0 ;
				
				//Input array elements
				Scanner scanner = new Scanner(System.in);
				System.out.println("Enter array elements");
				
				for(int i=0;i<a.length;i++) {
					a[i]=scanner.nextInt();
				}
				
				//display array elements
				for(int i=0;i<a.length;i++) {
					System.out.println(a[i]);
				}
				
				//find the sum of all array elements
				
				for(int i=0;i<a.length;i++) {
					sum=sum+a[i];
				}
				
				System.out.println("sum of all array elements "+sum);
				
				//average
				float avg =(float) sum/a.length;
				System.out.println("avg of the elements :"+avg);
				
				//max elements
				int max = a[0];
				
				for(int i=1;i<a.length;i++) {
					if(a[i]>max) {
						max=a[i];
					}
				}
				System.out.println("Maximum :"+max);
				
				//min element
				int min = a[0];
				
				for(int i=1;i<a.length;i++) {
					if(a[i]<min) {
						max=a[i];
					}
				}
				System.out.println("Minimum :"+min);
	}

}
