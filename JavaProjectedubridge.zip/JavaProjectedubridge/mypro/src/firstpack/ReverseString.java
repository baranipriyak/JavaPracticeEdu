//Java String Program to Reverse a String
package firstpack;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		String str1;
		Scanner sc = new Scanner (System.in);
		str1 = sc.nextLine();
		String reverse = "";
		
		for(int i=str1.length()-1;i>=0;i--) {
			reverse +=str1.charAt(i);
		}
		System.out.println(reverse);

	}

}
