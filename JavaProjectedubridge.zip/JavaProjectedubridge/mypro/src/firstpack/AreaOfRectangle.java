package firstpack;

public class AreaOfRectangle {

	public static void main(String[] args) {
		double length = 30;
		double width =20;
		double area=length*width;
		System.out.println("Area of Rectangle: "+area);

	}

}
