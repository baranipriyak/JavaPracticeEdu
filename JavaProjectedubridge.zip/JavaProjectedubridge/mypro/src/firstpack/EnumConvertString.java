//Java program to convert Enum to String 
package firstpack;

public class EnumConvertString {
	
	enum fruits{ 
		Orange,
		Apple,
		Banana,
		Mango;}

	public static void main(String[] args) {
		
		//using name function print the enum names 
		System.out.println(fruits.Orange.name());
		System.out.println(fruits.Apple.name());
		System.out.println(fruits.Banana.name());
		System.out.println(fruits.Mango.name());
		
		//using tostring method to print the enum names
		System.out.println(fruits.Orange.toString());
		System.out.println(fruits.Apple.toString());
		System.out.println(fruits.Banana.toString());
		System.out.println(fruits.Mango.toString());
		
		

	}

}

