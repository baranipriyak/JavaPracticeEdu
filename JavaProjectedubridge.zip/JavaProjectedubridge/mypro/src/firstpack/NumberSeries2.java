//1/1! + 1/2! + 1/3! + 1/4! + ......... +1/10!

package firstpack;

public class NumberSeries2 {

	public static void main(String[] args) {
		double result=0.0;
		int product , num=1;
		for(int i=1;i<=10;i++) {
			product=1;
			for(int j=i;j>=1;j--) {
				product*=j;
			}
			result +=(double)num/product;
		}
		System.out.println("1/1!+1/2!+1/3!+1/4!+.......+1/10! = "+result);

	}

}
