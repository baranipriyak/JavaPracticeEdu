package firstpack;

public class DoWhileLoopEven {

	public static void main(String[] args) {
		int i=2,sum=0;
		do {
			sum = sum+i;
			i=i+2;
		}while(i<=100);
		System.out.println("The sum of even numbers 1 to 100 :"+sum);
		

	}

}
