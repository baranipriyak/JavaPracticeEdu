package firstpack;

public class ForLoopEven {

	public static void main(String[] args) {
		int i,sum = 0;
		for(i=2;i<=100;i++) {
			sum +=i;
		}
		System.out.println("The sum of even numbers 1 to 100 :"+sum);

	}

}
