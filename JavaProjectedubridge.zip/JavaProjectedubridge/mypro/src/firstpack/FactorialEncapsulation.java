package firstpack;

import java.util.Scanner;

class Fact{
	int num;
	double fact=1;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		num=sc.nextInt();
	}
	
	void calculate() {
		for(int i=1;i<=num;i++) {
			fact*=i;
		}
	}
	
	void print() {
		System.out.println("The factorial of :"+fact);
	}
}

public class FactorialEncapsulation {

	public static void main(String[] args) {
		
		Fact f = new Fact();
		f.inputData();
		f.calculate();
		f.print();

	}

}
