package firstpack;

public class DiffDataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte num1=126;
		short num2=30000;
		int num3=10;
		long num4 = 76574l;
		float num5= 78.7F;
		double num6= 65.78;
		char initial = 'V';
		String name="Baranipriya";
		
		System.out.println("Byte Value: "+num1);
		System.out.println("Short Value: "+num2);
		System.out.println("Integer Value: "+num3);
		System.out.println("Long Value: " +num4);
		System.out.println("Float Value: "+num5);
		System.out.println("double Value: "+num6);
		System.out.println("Character value: "+initial);
		System.out.println("String Value: "+name);
		

	}

}
