package firstpack;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ClassesAndObjects {
	//instance variables
	int age;
	String name;
	float salary;
	char gen;
	
	
	void inputData() throws IOException {
		//input data from user
		
				//create an object of BufferedReader
				
				InputStreamReader is = new InputStreamReader(System.in);
				BufferedReader br =new BufferedReader(is);
				
				//BufferedReader br =new BufferedReader(new InputStreamReader(System.in));


				//two methods read() , readLine()
				
				System.out.println("Enter name");
				name = br.readLine();
				
				System.out.println("Enter age");
				age = Integer.parseInt(br.readLine()); //"56"
				
				System.out.println("Enter salary");
				salary =Float.parseFloat(br.readLine());
				
				System.out.println("Enter gender");
			//	gen = br.readLine().charAt(0);
				
				gen =(char) br.read(); //A-65 to 90 
				
	}
	
	void displayData() {
		System.out.println("Name = "+name);
		System.out.println("Age ="+age);
		System.out.println("Salary ="+salary);
		System.out.println("Gender="+gen);
	}
	
	public static void main(String[] args) throws IOException {
		System.out.println("Main Method");
		
		//create an object
		
		ClassesAndObjects cao = new ClassesAndObjects();
		
		//call the method
		
		cao.inputData();
		cao.displayData();


	}


}

