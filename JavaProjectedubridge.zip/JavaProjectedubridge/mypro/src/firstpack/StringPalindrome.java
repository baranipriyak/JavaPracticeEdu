//Java String Program to check whether a string is a palindrome

package firstpack;

import java.util.Scanner;

public class StringPalindrome {

	public static void main(String[] args) {
		String str1 ;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the word");
		str1 = sc.nextLine();
		String str2 = "";
		for(int i = (str1.length()-1);i>=0;i--) {
			str2+=str1.charAt(i);
		}
		if(str1.equalsIgnoreCase(str2)) {
			System.out.println("It is a palindrome");
		}
		else {
			System.out.println("It is not a palindrome");
		}

	}

}
