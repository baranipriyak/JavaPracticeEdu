package firstpack;

import java.util.Scanner;

class Factors{
	int num ;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number :");
		num = sc.nextInt();
	}
	
	void calculate() {
		for(int i=1 ; i<=num ; i++) {
			
			if (num%i == 0) {
				System.out.print(i +" ");
			}
		}
	}
}

public class FactorsEncapsulation {
	public static void main(String args[]) {
		Factors f = new Factors();
		f.inputData();
		f.calculate();
		
	}
}
