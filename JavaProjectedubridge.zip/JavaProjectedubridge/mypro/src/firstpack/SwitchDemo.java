package firstpack;


import java.util.Scanner;


public class SwitchDemo {


	public static void main(String[] args) {
		int option, result;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("1. Addition");
		System.out.println("2. Subtracion");
		System.out.println("3. Multiplication");
		System.out.println("4. Division");
		System.out.println("Enter your choice");
		option = scanner.nextInt();
		
		System.out.println("Enter 2 numbers");
		int n1 = scanner.nextInt();
		int n2 = scanner.nextInt();
		
		switch(option) { ///int char or String
		 
		     
		case 1: result = n1+n2;
		        System.out.println("The sum of "+n1+" and "+n2+" is "+result);
		        break;
		default: System.out.println("Invalid input");
		         break;
		case 2: result = n1-n2;
        System.out.println("The difference of "+n1+" and "+n2+" is "+result);
        		break;
        
		case 3: result = n1*n2;
        System.out.println("The product of "+n1+" and "+n2+" is "+result);
        		break;
        
		case 4: 
			    if(n2!=0) {
			    	result = n1/n2;
			    	  System.out.println("The quotient of "+n1+" and "+n2+" is "+result);
			    }
			    else {
			    	System.out.println("Divide by zero error");
			    }
        		break;
       
        
		   
		}
		
		


	}


}
