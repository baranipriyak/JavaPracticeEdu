package firstpack;

import java.util.Scanner;

public class BookFair {
	String bname;
	double price;
	
	BookFair(String bname , double price){
		this.bname = bname;
		this.price = price;
		
	}
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the book name :");
		bname = sc.nextLine();
		System.out.println("Enter the Book price :");
		price = sc.nextDouble();
	}
	
	void calculate() {
		double discount ;
		if(price<=1000) {
			discount = price*2.0/100;
			price -=discount;
			
		}
		else if(price>1000 && price<=3000) {
			discount = price*10.0/100;
			price -=discount;
		}
		else if (price>3000) {
			discount = price*15.0/100;
			price -=discount;
		}
	}
	
	void display() {
		System.out.println("The Book name is :"+bname);
		System.out.println("The Book price after discount :"+price);
	}

	public static void main(String[] args) {
		BookFair bf = new BookFair("Seethakathi",2566);
//		bf.input();
		bf.calculate();
		bf.display();
		
		

	}

}
