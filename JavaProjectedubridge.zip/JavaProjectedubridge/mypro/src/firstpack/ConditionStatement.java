package firstpack;

public class ConditionStatement {

	public static void main(String[] args) {
		int a=10,b=20,c=90,d=56;
		
		int large = (a>b)?a:b;
		
		System.out.println("the largest of "+a+" and "+b+" is "+large);
		
		int large1 = (a>b && a>c)?a:(b>a && b>c)?b:c;
		
		System.out.println("the largest of "+a+" , "+b+" and "+c+ " is "+large1);
		
		int large2 = (a>b && a>c && a>d)?a:(b>a && b>c && b>d)?b:(c>a && c>b && c>d)?c:d;
		
		System.out.println("the largest of "+a+" , "+b+" , "+c+" and "+d+" is "+large2);

	}

}
