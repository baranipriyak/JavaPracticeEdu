package firstpack;

public class AreaOfTriangle {

	public static void main(String[] args) {
		double length=20;
		double width=16;
		double area = (length*width)/2;
		
		System.out.println("Area of Triangle : "+area);
		

	}

}
