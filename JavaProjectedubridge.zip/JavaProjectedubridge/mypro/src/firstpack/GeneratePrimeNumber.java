package firstpack;

public class GeneratePrimeNumber {

	public static void main(String[] args) {
		//1 to 100
				int c;
				for(int num=1;num<=100;num++) {
					c=0;
					for(int i=1;i<=num;i++) {
						if(num%i==0) {
							c++;
						}
					}
					if(c==2) {
						System.out.print(num+" ");
					}
					
				}

	}

}
