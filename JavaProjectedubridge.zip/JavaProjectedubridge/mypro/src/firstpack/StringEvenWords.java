//Java String program to print even length words
package firstpack;

public class StringEvenWords {

	public static void main(String[] args) {
		
		String str = "Baranipriya";
		
		for(int i=0;i<str.length();i++) {
			if (i%2==1) {
				System.out.println(str.charAt(i));
			}
		}

	}

}
