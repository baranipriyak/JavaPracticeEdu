package firstpack;

public class ArmstrongNumber1to1000 {

	public static void main(String[] args) {
		int num  , cnt , reminder ;
		double arm;
		for ( int i=1 ;i<1000;i++) {
//			System.out.println(i);
			num=i;
			arm=0;
			cnt=0;
			while (num!=0) {
				cnt+=1;
				num/=10;
//				System.out.println(num);
//				System.out.print(cnt+" ");
			}
			num=i;
//			System.out.println(num);
			while (num !=0) {
				reminder = num%10;
//				System.out.print(reminder+" ");
				arm =arm+ (Math.pow(reminder,cnt));
//				System.out.print(arm+" ");
				num = num/10;
			}
//			System.out.println(i==arm);
			if(i == arm) {
				System.out.println(i);
			}
		
		}
		
	}

}
