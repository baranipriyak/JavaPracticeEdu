//Java program to Iterate Over Characters in String
package firstpack;

import java.text.*;

public class IterateOverCharacters {

	public static void main(String[] args) {
		String str = "Baranipriya";
		for(int i=0;i<str.length();i++) {
			System.out.print(str.charAt(i)+" ");
		}
		System.out.println();
		
		
		
		//Another method to solve the same problem using iterator class
		
		CharacterIterator itr = new StringCharacterIterator(str);
		
		while (itr.current()!=CharacterIterator.DONE) {
			System.out.print(itr.current()+" ");
			itr.next();
		}

	}

}


