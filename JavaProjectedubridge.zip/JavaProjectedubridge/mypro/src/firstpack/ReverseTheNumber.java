package firstpack;

import java.util.Scanner;

class Reverse{
	int num , reverse , reminder;

	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number :");
		num = sc.nextInt();
	}
	void reverseNumber() {
		reverse = 0;
		while(num != 0) {
			reminder = num%10;
			reverse = (reverse*10) + reminder;
			num = num/10;
		}
		System.out.println(reverse);
	}
}

public class ReverseTheNumber {

	public static void main(String[] args) {
		Reverse rev = new Reverse();
		rev.inputData();
		rev.reverseNumber();

	}

}
