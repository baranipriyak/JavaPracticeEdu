package firstpack;

import java.util.Scanner;

class Palindrome{
	
	int num , reverse , reminder , num1;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number :");
		num = sc.nextInt();
		num1=num;
		
	}
	void calculate() {
		while(num != 0) {
			reminder = num%10;
			reverse = reverse*10+reminder;
			num=num/10;
		}
	}
	void print() {
		if (num1 == reverse) {
			System.out.println("It is a Palindrome");
		}
		else {
			System.out.println("It's not a Palindrome");
		}
	}
}

public class PalindromeEncapsulation {

	public static void main(String[] args) {
		
		Palindrome p = new Palindrome();
		p.inputData();
		p.calculate();
		p.print();

	}

}
