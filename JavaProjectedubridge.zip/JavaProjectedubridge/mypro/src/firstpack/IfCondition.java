package firstpack;

public class IfCondition {
	

	public static void main(String[] args) {
		int a=10;
		if (a<15) {
			System.out.println("Hello good morning!");
		}

	}

}
