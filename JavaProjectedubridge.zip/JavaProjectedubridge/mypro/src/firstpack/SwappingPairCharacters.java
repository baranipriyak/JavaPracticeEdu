//java String program to swapping pair of characters
package firstpack;

public class SwappingPairCharacters {

	public static void main(String[] args) {
		
		String str1 = "Barani";
		char char_array[] = str1.toCharArray();
		
		for (int i=0;i<char_array.length-1;i=i+2) {
			char temp = char_array[i];
			char_array[i] = char_array[i+1];
			char_array[i+1]=temp;
			
		}
		
		System.out.println("print array of swapping character :");
		
		for(int i=0;i<char_array.length;i++) {
			
			System.out.print(char_array[i]);
			
		}

	}

}
